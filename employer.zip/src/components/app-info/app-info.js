import './app-info.css'

const AppInfo = () =>{
    return(
        <div className="app-info">
            <h1>Облік працівників в компанії ШТОРМ</h1>
            <h2>Загальна кількість співробітників: </h2>
            <h2>Премію отримають: </h2>
        </div>
    )
}

export default AppInfo;